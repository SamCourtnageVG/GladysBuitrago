# Portafolio – GitHub Pages

Este sitio está listo para publicarse en GitHub Pages.

## Cómo usar
1. Crea el repositorio `tuusuario.github.io` en GitHub.
2. Sube el contenido de esta carpeta (index.html, style.css y la carpeta `images/`).
3. Abre **Settings → Pages**, selecciona la rama `main` y carpeta `/root`.

## Reemplazar imágenes
Ya exporté cada página de tu PDF a imágenes dentro de `images/`.

## Personaliza el contenido
Edita `index.html` para cambiar textos, orden de secciones o añadir más proyectos.
